var rows = [
  {
    name: "John",
    position: "Engineer",
    office: "Megha",
    extn: "5764",
    startdate: "2023-10-12",
    salary: "100000",
  },
  {
    name: "Jason",
    position: "Software",
    office: "Westgate",
    extn: "1982",
    startdate: "2023-10-12",
    salary: "20000",
  },
];

function addrow() {
  var fnamenew = document.getElementById("name").value;
  var positionnew = document.getElementById("position").value;
  var officenamenew = document.getElementById("officename").value;
  var extnnew = document.getElementById("extn").value;
  var startdatenew = document.getElementById("startdate").value;
  var salarynew = document.getElementById("salary").value;

  var employee = {
    name: fnamenew,
    position: positionnew,
    office: officenamenew,
    extn: extnnew,
    startdate: startdatenew,
    salary: salarynew,
  };
  rows.push(employee);
  showTable();
}



function deleterow(){
    var row = btn.parentNode.parentNode;
    row.parentNode.removeChild(row);
}

window.onload = function () {
  showTable();
};

function showTable() {
  var html = "<table border='1|1'>";
  for (var i = 0; i < rows.length; i++) {
    html += "<tr>";
    html += "<td>" + rows[i].name + "</td>";
    html += "<td>" + rows[i].position + "</td>";
    html += "<td>" + rows[i].office + "</td>";
    html += "<td>" + rows[i].extn + "</td>";
    html += "<td>" + rows[i].startdate + "</td>";
    html += "<td>" + rows[i].salary + "</td>";
    html += "<td>" + `<button class='btn edit-btn' onclick="editrow()">Edit</button>` + "</td>";  
    html += "<td>" + `<button class='btn delete-btn' onclick="deleterow()">Delete</button>` + "</td>";  
}
  html += "</table>";
  $(".show-data").html(html);
}

// function addrow() {
//     var fnamenew = document.getElementById("name").value;
//     var positionnew = document.getElementById("position").value;
//     var officenamenew = document.getElementById("officename").value;
//     var extnnew = document.getElementById("extn").value;
//     var startdatenew = document.getElementById("startdate").value;
//     var salarynew = document.getElementById("salary").value;

//     tbodyEl.innerHTML += `
//     <tr>
//         <td>${fnamenew}</td>
//         <td>${positionnew}</td>
//         <td>${officenamenew}</td>
//         <td>${extnnew}</td>
//         <td>${startdatenew}</td>
//         <td>${salarynew}</td>
//     </tr>
//     `;
// }
